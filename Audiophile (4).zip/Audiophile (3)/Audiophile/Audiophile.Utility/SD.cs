﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.Utility
{
    public static class SD
    {
        public const string SessionCart = "Cart";

    }
}
