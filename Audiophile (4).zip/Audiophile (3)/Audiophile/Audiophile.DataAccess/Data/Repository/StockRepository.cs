﻿using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Audiophile.DataAccess.Data.Repository
{
    public class StockRepository : Repository<Stock>, IStockRepository
    {
        private readonly ApplicationDbContext _db;

        public StockRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetStockListForDropDown()
        {
            return _db.Stock.Select(i => new SelectListItem()
            {
                Text = i.Name,
                Value = i.Id.ToString()
            });
        }

        public void Update(Stock stock)
        {
            var objFromDb = _db.Stock.FirstOrDefault(s => s.Id == stock.Id);

            objFromDb.Name = stock.Name;
            objFromDb.StockCount = stock.StockCount;

            _db.SaveChanges();
        }

    }
}
