﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Audiophile.Models.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Genre> GenreList { get; set; }
        public IEnumerable<Record> RecordList { get; set; }
    }
}
