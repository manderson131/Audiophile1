﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Audiophile.Models
{
    public class OrderDetails
    {
        public int Id { get; set; }

        [Required]
        public int OrderHeaderId { get; set; }
        [ForeignKey("OrderHeaderId")]
        public OrderHeader OrderHeader { get; set; }

        [Required]
        public int RecordId { get; set; }
        [ForeignKey("RecordId")]
        public Record Record { get; set; }

        [Required]
        public string RecordName { get; set; }

        [Required]
        public double Price { get; set; }
    }
}
