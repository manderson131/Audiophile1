﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Audiophile.DataAccess.Data.Repository;
using Audiophile.DataAccess.Data.Repository.IRepository;
using Audiophile.Extensions;
using Audiophile.Models;
using Audiophile.Models.ViewModels;
using Audiophile.Utility;
using Microsoft.AspNetCore.Mvc;

namespace Audiophile.Areas.Customer.Controllers
{   [Area("Customer")]
    public class CartController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        [BindProperty]
        public CartViewModel CartVM { get; set; }
        public CartController (IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
            CartVM = new CartViewModel()
            {
                OrderHeader = new Models.OrderHeader(),
                RecordList = new List<Record>()
            };
        }

        public IActionResult Index()
        {

            if (HttpContext.Session.GetObject<List<int>>(SD.SessionCart) != null)
            {
                List<int> sessionList = new List<int>();
                sessionList = HttpContext.Session.GetObject<List<int>>(SD.SessionCart);
                foreach(int recordId in sessionList)
                {
                    CartVM.RecordList.Add(_unitOfWork.Record.GetFirstOrDefault(u => u.Id == recordId,inculdeProperties:"Stock,Genre"));
                }
            }
            return View(CartVM);
        }
    }
}